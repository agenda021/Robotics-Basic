#include <REG51F.H>

sbit svm=P1^6;

void left(void);
void centre(void);
void right(void);
void delay(void);
//====================================

void main(void)
{

	unsigned int i;
	while(1)
	{
	
		for(i=0;i<200;i++)
		{
		
			left();
		}
		delay();

		for(i=0;i<100;i++)
		{
		
			centre();
		}
		delay();

		for(i=0;i<100;i++)
		{
		
			right();
		}
		delay();
				
	}
}
//======================================

void left(void)
{

	TMOD=0X01;
	TH0=0XFB;
	TL0=0X7F;
	TR0=1;
	while(!TF0){}
	svm=~svm;
	TF0=0;
	TR0=0;
}
//========================================

void centre(void)
{

	TMOD=0X01;
	TH0=0XFA;
	TL0=0X99;
	TR0=1;
	while(!TF0){}
	svm=~svm;
	TF0=0;
	TR0=0;
}
//========================================

void right(void)
{

	TMOD=0X01;
	TH0=0XF9;
	TL0=0XB3;
	TR0=1;
	while(!TF0){}
	svm=~svm;
	TF0=0;
	TR0=0;
}
//========================================

void delay(void)
{

	unsigned int a,b;
	for(b=0;b<120;b++)
	{
		for(a=0;a<120;a++)
		{
		
		}
	}

}
//=========================================
https://mail.google.com/mail/?shva=1#inbox