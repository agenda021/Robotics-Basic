#include <Philips\8xC31-51-80C51Fx-80C51Rx+.h>
#include <standard.h>
BIT	en1		P1.0;
BIT	ldc1	P1.1;
BIT	ldc2	P1.2;
BIT	rdc1	P1.3;
BIT	rdc2	P1.4;
BIT	en2		P1.5;

void main ()
{

}
