#include <Philips\8xC31-51-80C51Fx-80C51Rx+.h>
#include <standard.h>
BIT	en1		P1.0;
BIT	ldc1	P1.1;
BIT	ldc2	P1.2;
BIT	rdc1	P1.3;
BIT	rdc2	P1.4;
BIT	en2		P1.5;


void main ()
{
	en1=en2=1;
	
	while(1)
	{
		ldc1=1;
		ldc2=0;
		rdc1=1;
		rdc2=0;
	
		delay_ms(3000);
	
		ldc1=0;
		ldc2=1;
		rdc1=0;
		rdc2=1;
	
		delay_ms(3000);
	}
}
