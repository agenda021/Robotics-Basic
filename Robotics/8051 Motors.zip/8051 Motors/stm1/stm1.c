#include <Philips\8xC31-51-80C51Fx-80C51Rx+.h>
#include <stdio.h>
#include <standard.h>

/*----------------------Defining SFR bits here------------------------------*/
BIT	stm1	P3.4;
BIT	stm2	P3.5;
BIT	stm3	P3.6;
BIT	stm4	P3.7;
/*---------------------------------------------------------------------------*/
void main()
{				
	
	while(1)				//infinite loop 
		{
			stm1=1;
			stm2=1;
			stm3=0;
			stm4=0;
			delay_ms(2);
			
			stm1=0;
			stm2=1;
			stm3=0;
			stm4=0;
			delay_ms(2);
			
			stm1=0;
			stm2=1;
			stm3=1;
			stm4=0;
			delay_ms(2);
			
			stm1=0;
			stm2=0;
			stm3=1;
			stm4=0;
			delay_ms(2);
			
			stm1=0;
			stm2=0;
			stm3=1;
			stm4=1;
			delay_ms(2);
			
			stm1=0;
			stm2=0;
			stm3=0;
			stm4=1;
			delay_ms(2);
			
			stm1=1;
			stm2=0;
			stm3=0;
			stm4=1;
			delay_ms(2);
			
			stm1=1;
			stm2=0;
			stm3=0;
			stm4=0;
			delay_ms(2);
					
		}
		
}
