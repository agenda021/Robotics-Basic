#include <Philips\8xC31-51-80C51Fx-80C51Rx+.h>
#include <stdio.h>
#include <standard.h>
#include <macros31.h>
#include <stdlib.h>

/*----------------------Defining SFR bits here------------------------------*/
BIT	l_en	P1.0;
BIT	ldc1	P1.1;
BIT	ldc2	P1.2;
BIT	rdc1	P1.3;
BIT	rdc2	P1.4;
BIT	r_en	P1.5;
 						
/*---------------------------------------------------------------------------*/
/*----------------------Defining user defined bits here-----------------------*/
bit	left_speed;
bit	right_speed;
/*---------------------------------------------------------------------------*/
/*----------------------Defining user bytes here-----------------------------*/
unsigned char count1=100; 
unsigned char count2=100;
unsigned char count3=200;

unsigned char job=00;
unsigned char job_old=00;
/*---------------------------------------------------------------------------*/


/*----------------------Function declaration---------------------------------*/							
void init_timer0();
void init_ex0();
void init_ex1();
void motor_drive();
/*---------------------------------------------------------------------------*/

/* ISR for Timer0--------------------*/
interrupt(INT_TMR0) isr_t0() using 1 
	{
		
		init_timer0();			//initalise timer0 for 1ms
		motor_drive();
						
	}		
/*-----------------------------------*/
/* ISR for ex0--------------------*/
interrupt(INT_EXT0) isr_ex0() using 2 
	{
		
		job=0x03;				//left
		
	}		
/*-----------------------------------*/
/* ISR for ex0--------------------*/
interrupt(INT_EXT1) isr_ex1() using 2 
	{
		
		job=0x04;				//right
							
	}		
/*-----------------------------------*/
	
	
/*---------------------------------------------------------------------------*/
void main()
{		
	init_timer0();
	enable_t0();		 	//enable timer0 int
	
	init_ex0();	
	init_ex1();		
	
	
	while(1)				//infinite loop 
		{
			
					
		}
		
}
/*---------------------------------------------------------------------------*/

/*-----------------------------------*/
void init_timer0()
{
	TMOD|=0x01;					//Timer0 in mode 1
	
	TH0=0x0d8;					//count for 10msec
	TL0=0x0ef;
	set_hi_t0()
	start_timer0();				

}
/*-----------------------------------*/

/*-----------------------------------*/
void init_ex0()
{
	ex0_edge();
	enable_ex0()				
	count1=50;
	count2=50;
}
/*-----------------------------------*/
/*-----------------------------------*/
void init_ex1()
{
	ex1_edge();
	enable_ex1()				
	count1=50;
	count2=50;
}
/*-----------------------------------*/


/*-----------------------------------*/
void motor_drive()
{

	if(job!=job_old)
	{
		count1=50;
		count2=50;
		count3=200;
	}
/*-----------------------------------*/	
	job_old=job;

	switch(job)
	{
		case 00:		//forward
			left_speed=1;		//full speed
			right_speed=1;		//full speed
			
			ldc1=1;		//left forward
			ldc2=0;
			rdc1=1;		//right forward
			rdc2=0;	
			break;
			
		case 01:			//reverse and forward right
			if(count1!=0)	
			{
				left_speed=1;		//full speed
				right_speed=1;		//full speed
				
				ldc1=0;		//left reverse
				ldc2=1;
				rdc1=0;		//right reverse	
				rdc2=1;			
				
				count1--;
				break;
			}
			
			if(count2!=0)
			{
				l_en=1;		//
				r_en=1;
				
				ldc1=1;		//left forward
				ldc2=0;
				rdc1=0;		//right stoped
				rdc2=0;			
				
				count2--;
				break;
			}
			
			job=00;
			count1=50;
			count2=50;
			break;
			
		case 02:			//reverse and forward left
			if(count1!=0)	
			{
			left_speed=1;		//full speed
			right_speed=1;		//full speed
				
			ldc1=0;		//left reverse
			ldc2=1;
			rdc1=0;		//right reverse	
			rdc2=1;			
			
			count1--;
			break;
			}
		
			if(count2!=0)
			{
				l_en=1;		//
				r_en=1;
				
				ldc1=0;		//left stoped
				ldc2=0;
				rdc1=1;		//right forward
				rdc2=0;			
				
				count2--;
				break;
			}
			job=00;
			count1=50;
			count2=50;
			break;
				
		case 03:			//reverse and backward left
			if(count1!=0)	
			{
			
			left_speed=1;		//full speed
			right_speed=1;		//full speed
						
			ldc1=0;		//left reverse
			ldc2=1;
			rdc1=0;		//right reverse	
			rdc2=1;			
			
			count1--;
			break;
			}
		
			if(count2!=0)
			{
				l_en=1;		//
				r_en=1;
				
				ldc1=0;		//left stoped
				ldc2=0;
				rdc1=0;		//right reversed
				rdc2=1;			
				
				count2--;
				break;
			}
			job=00;
			count1=50;
			count2=50;
			break;
		
		case 04:			//reverse and backward left
			if(count1!=0)	
			{
			
			left_speed=1;		//full speed
			right_speed=1;		//full speed
						
			ldc1=0;		//left reverse
			ldc2=1;
			rdc1=0;		//right reverse	
			rdc2=1;			
			
			count1--;
			break;
			}
		
			if(count2!=0)
			{
				l_en=1;		//
				r_en=1;
				
				ldc1=0;		//left reversed
				ldc2=1;
				rdc1=0;		//right stoped
				rdc2=0;			
				
				count2--;
				break;
			}
			job=00;
			count1=50;
			count2=50;
			break;
		
		case 05:			//backwrd left
			if(count3!=0)
			{
				left_speed=0;		//half speed
				right_speed=1;		//full speed
				
				ldc1=0;		//left reversed
				ldc2=1;
				rdc1=0;		//right reversd
				rdc2=1;	
				
				count3--;
				break;
			}
			job=00;
			count3=200;
			break;
		
		case 06:			//backwrd right
			if(count3!=0)
			{
				left_speed=1;		//full speed
				right_speed=0;		//half speed
				
				ldc1=0;		//left reversed
				ldc2=1;
				rdc1=0;		//right reversd
				rdc2=1;	
				
				count3--;
				break;
			}
			job=00;
			count3=200;
			break;		
		default:
			l_en=1;		//default action
			r_en=1;
			
			ldc1=1;		//left forward
			ldc2=0;
			rdc1=1;		//right forward
			rdc2=0;	
			break;
	}
/*-----------------------------------*/	
	if(left_speed)
	{
		l_en=1;
	}
	else
	{
		l_en=!l_en;
	}	
	
	if(right_speed)
	{
		r_en=1;
	}
	else
	{
		r_en=!r_en;
	}
		
/*-----------------------------------*/
}
/*-----------------------------------*/
