#include <REG51F.H>
#include <stdio.h>
sbit en1=P1^0;
sbit dcm1=P1^1;
sbit dcm2=P1^2;
void init_uart();
unsigned char uart_rx();
void delay(unsigned int t);
unsigned char ch1;
void main()
{
init_uart();
en1=1;
printf("\n f->forward; r->reverse; s->stop");
while(1)
{
ch1=uart_rx();
switch(ch1)
{
case 'f':
     dcm1=1;
	 dcm2=0;
	 delay(100);
	 break;

case 'r':
     dcm1=0;
	 dcm2=1;
	 delay(100);
	 break;

case 's':
     dcm1=0;
	 dcm2=0;
	 delay(100);
	 break;
}
}
}
void delay(unsigned int t)
{
unsigned int i, j;
for(i=0;i<=t;i++)
{
for(j=0;j<=120;j++);
}
}

void init_uart()
{
SCON=0x52;
TMOD=0x20;
TH1=0xFD;
TR1=1;
}

unsigned char uart_rx()
{
while(RI==0);
ch1=SBUF;
RI=0;
return(ch1);
}