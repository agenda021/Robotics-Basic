#include <REG51F.H>
sbit EN2=P1^5;

sbit DCM3=P1^3;
sbit DCM4=P1^4;

void m_delay(unsigned int);
void main()
{
EN2=1;
while(1)
	{
   
	DCM3=1;
	DCM4=0;
	m_delay(1000);
	DCM3=0;
	DCM4=1;
	m_delay(1000);
}
}

void m_delay(unsigned int t)
{
unsigned int i, j;
for(i=0;i<=t;i++)
{
for(j=0;j<=600; j++);
}
}
