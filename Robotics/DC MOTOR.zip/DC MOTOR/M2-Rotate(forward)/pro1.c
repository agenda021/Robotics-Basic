#include <REG51F.H>
sbit EN2=P1^5;

sbit DCM3=P1^3;
sbit DCM4=P1^4;

void m_delay(unsigned int);
void main()
{
EN2=1;
while(1)
	{
   
	DCM3=1;
	DCM4=0;
	m_delay(100);
}
}

void m_delay(unsigned int t)
{
unsigned int i, j;
for(i=0;i<=t;i++)
{
for(j=0;j<=120; j++);
}
}
