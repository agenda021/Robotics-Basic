#include <REG51F.H>
sbit EN1=P1^0;
sbit DCM1=P1^1;
sbit DCM2=P1^2;
sbit DCM3=P1^3;
sbit DCM4=P1^4;
sbit EN2=P1^5;

void m_delay(unsigned int);
void main()
{
EN1=1;
EN2=1;
while(1)
{
DCM1=0;
DCM2=1;
DCM3=0;
DCM4=1;
m_delay(100);
}
}

void m_delay(unsigned int t)
{
unsigned int i, j;
for(i=0;i<=t;i++)
{
for(j=0;j<=120;j++);
}
}
