#include <REG51F.H>
sbit EN1=P1^0;

sbit DCM1=P1^1;
sbit DCM2=P1^2;
	sbit EN2=P1^6;

sbit DCM3=P1^3;
sbit DCM4=P1^4;

void m_delay(unsigned int);
void main()
{
EN1=1;
EN2=1;
//while(1)
	{
   
	DCM1=0;
	DCM2=1;
	m_delay(1000);
	
	DCM3=0;
	DCM4=1;
	m_delay(1000);
	
	DCM1=1;
	DCM2=0;
	m_delay(1000);
	
	DCM3=1;
	DCM4=0;
	m_delay(1000);
}
	EN1=0;
	m_delay(1000);
	EN2=0;
while(1){};
}

void m_delay(unsigned int t)
{
unsigned int i, j;
for(i=0;i<=t;i++)
{
for(j=0;j<=120; j++);
}
}
