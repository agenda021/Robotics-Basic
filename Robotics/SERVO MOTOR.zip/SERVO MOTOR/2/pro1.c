#include <REG51F.H>

sbit svm=P1^6;
void delay(unsigned int time);
void main()
{
unsigned int i;
while(1)
{
for(i=0;i<=50;i++)
{
svm=1;
delay(1.75);
svm=0;
delay(16.25);
}
for(i=0;i<=50;i++)
{
svm=1;
delay(2.0);
svm=0;
delay(16.0);
}
}
}
void delay(unsigned int time)
{
unsigned int j, k;
for(j=0;j<=time;j++)
for(k=0;k<=120;k++);
}