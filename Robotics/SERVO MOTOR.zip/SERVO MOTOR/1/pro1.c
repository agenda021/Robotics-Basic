#include <REG51F.H>
void sm_delay(unsigned int);
sbit svm=P1^6;
void main()
{
unsigned int i;
while(1)
{
for(i=0;i<50;i++)
{
svm=1;
sm_delay(1000);
svm=0;
sm_delay(20);
}
for(i=0;i<50;i++)
{
svm=1;
sm_delay(2000);
svm=0;
sm_delay(20);
}
}
}

void sm_delay(unsigned int itime)
{
unsigned int i, j;
for(i=0;i<itime;i++)
{
j++;
}
}