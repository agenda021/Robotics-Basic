#include <REG51F.H>
sbit sum=P1^6;
void left(void);
void right(void);
void centre(void);
void delay(unsigned int t);
void main()
{
unsigned int i;
while(1)
{
for(i=0;i<300;i++)
{
left();
}
delay(100);
for(i=0;i<300;i++);
{
centre();
}
delay(100);
for(i=0;i<300;i++)
{
right();
}
delay(100);
}
}

void left(void)
{
TMOD=0x01;
TH0=0xfb;
TL0=0x7f;
TR0=1;
while(!TF0);
{
}
sum=~sum;
TF0=0;
TR0=0;
}
void centre(void)
{
TMOD=0x01;
TH0=0xfa;
TL0=0x99;
TR0=1;
while(!TF0)
{
}
sum=~sum;
TF0=0;
TR0=0;
}
void right(void)
{
TMOD=0x01;
TH0=0xf9;
TL0=0xb3;
TR0=1;
while(!TF0);
TF0=0;
{
}
sum=~sum;
TF0=0;
TR0=0;
}
void delay(unsigned int t)
{
unsigned int i,j;
for(i=0;i<=t;i++)
for(j=0;j<=120;j++);
}

